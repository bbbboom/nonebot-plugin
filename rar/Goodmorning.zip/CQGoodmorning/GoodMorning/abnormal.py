# -*- coding: utf-8 -*-

class Abnormal(Exception):
    pass