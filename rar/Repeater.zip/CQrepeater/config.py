
from nonebot.default_config import *

'''
notebot-bot
├── bot.py
└── config.py
'''

COMMAND_START = {''}

HOST = '127.0.0.1'
PORT = 8080


