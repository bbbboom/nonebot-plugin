# -*- coding: utf-8 -*-

FAILURE = 'failure'
SUCCESS = 'success'

DAY = 'day'
HOUR = 'hour'
MINUTE = 'minute'
SECOND = 'second'
ALL = 'all'