# -*- coding: utf-8 -*-

# Fatal error type
class GrailExcept(Exception):
    pass

